import { Component, Input, OnInit } from '@angular/core';
import { RequestService } from '../request.service';

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.css']
})
export class RequestsComponent implements OnInit {
  @Input() request: {name: string , author: string, img: string };
  servers: any[];
  constructor(private serverData: RequestService) { }

  ngOnInit(): void {
    this.servers = this.serverData.servers;
  }
  lend(data,index){
    this.serverData.addDataTolender(data);
    this.serverData.servers.splice(index,1)
  }

}
