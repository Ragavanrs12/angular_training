import { Component, Input, OnInit } from '@angular/core';
import { RequestService } from '../request.service';

@Component({
  selector: 'app-lending',
  templateUrl: './lending.component.html',
  styleUrls: ['./lending.component.css']
})
export class LendingComponent implements OnInit {
@Input() lending: {name: string , author: string, img: string };
  constructor(private serverData: RequestService) { }
lendData = [];
  ngOnInit(): void {
  this.lendData = this.serverData.lender;
  }
  return(form, index){
    this.serverData.lender.splice( index,1);
  
  }

}
