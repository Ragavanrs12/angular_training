import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'book';
  lending = [];
  
  submitnow(event: {name: string , author: string , img: string}) {
    this.lending.push({
      name: event.name,
      author: event.author,
      img: event.img
    });
}
}
