import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookComponent } from './book/book.component';
import { RequestsComponent } from './requests/requests.component';
import { LendingComponent } from './lending/lending.component';
import { PathnotfoundComponent } from './pathnotfound/pathnotfound.component';
import { AddbookComponent } from './addbook/addbook.component';
const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full'},
  { path: 'home', component: BookComponent},
  { path: 'request', component: RequestsComponent},
  { path: 'lending', component: LendingComponent},
  { path: 'addbook', component: AddbookComponent},
  {path: '**', component: PathnotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
