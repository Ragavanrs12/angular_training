import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pathnotfound',
  templateUrl: './pathnotfound.component.html',
  styleUrls: ['./pathnotfound.component.css']
})
export class PathnotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
