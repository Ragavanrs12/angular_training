import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { RequestService } from '../request.service';
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  // tslint:disable-next-line:no-output-rename
  @Output('requestdetail') request = new EventEmitter<{name: string, author: string, img: string }>();

  allProducts: any[];
constructor(private serverData: RequestService){}

  ngOnInit(): void {
    this.allProducts=this.serverData.allProducts;
  }
requestbook(product){
  this.serverData.addDataTorequest(product);
  this.request.emit({
    name: product.name,
    author: product.author,
    img: product.img
  });
}
}
