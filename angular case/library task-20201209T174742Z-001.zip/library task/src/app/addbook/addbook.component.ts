import { Component, OnInit } from '@angular/core';
import { RequestService } from '../request.service';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
name = '';
author = '';
img = '';
  constructor(private serverData: RequestService) { }

  ngOnInit(): void {
  }
  addbook(form){
    this.serverData.addDataToproduct(form);
    this.handleclear();
  }
handleclear(){
  this.name = '';
this.author = '';
this.img = '';
}
}
