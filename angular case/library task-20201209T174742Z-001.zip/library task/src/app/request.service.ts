import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RequestService {
  allProducts = [{
    name : 'MK Ghandhi autobiography',
    author : 'mk ghandhi' ,
    img: '../assets/41b4No1SuLL._SX321_BO1,204,203,200_.jpg'
  },
  {
    name : 'Long walk freedom',
    author : 'Nelson Mandela' ,
    img: '../assets/81Z5fX7qieL.jpg'
  },
  {
    name : 'My autobiography',
    author : 'Charlie Chaplin' ,
    img: '../assets/9781612191928.jpeg'
  },
  {
    name : 'the  autobiography of  franklin',
    author : 'Benjamin Franklin' ,
    img: '../assets/franklin (1).jpeg'
  },
  {
    name : 'Einstean',
    author : 'Walter Issac' ,
    img: '../assets/images.jpeg'
  },
  {
    name : 'the  autobiography of franklin',
    author : 'Benjamin Franklin' ,
    img: '../assets/franklin (1).jpeg'
  }
  

];
  servers = [];
  lender = [];
    constructor() { }
  // tslint:disable-next-line:typedef
  addDataTorequest(serverData){
    this.servers.push(serverData);
  }
  addDataTolender(serverData){
    this.lender.push(serverData);
  }
  addDataToproduct(serverData){
    this.allProducts.push(serverData);
  }

}
